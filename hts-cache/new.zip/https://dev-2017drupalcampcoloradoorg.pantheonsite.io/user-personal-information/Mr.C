<!DOCTYPE html>
<!--[if lt IE 7]> <html class="lt-ie9 lt-ie8 lt-ie7" lang="en"> <![endif]-->
<!--[if IE 7]>    <html class="lt-ie9 lt-ie8" lang="en"> <![endif]-->
<!--[if IE 8]>    <html class="lt-ie9" lang="en"> <![endif]-->
<!--[if gt IE 8]><!--> <html lang="en"> <!--<![endif]-->
<head>
  <title>DrupalCamp Colorado 2017 | July 28, 29, and 30</title>
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <meta name="Generator" content="Drupal 7 (http://drupal.org)" />
<link rel="shortcut icon" href="https://dev-2017drupalcampcoloradoorg.pantheonsite.io/misc/favicon.ico" type="image/vnd.microsoft.icon" />
<meta charset="utf-8" /><script type="text/javascript">window.NREUM||(NREUM={}),__nr_require=function(e,n,t){function r(t){if(!n[t]){var o=n[t]={exports:{}};e[t][0].call(o.exports,function(n){var o=e[t][1][n];return r(o||n)},o,o.exports)}return n[t].exports}if("function"==typeof __nr_require)return __nr_require;for(var o=0;o<t.length;o++)r(t[o]);return r}({1:[function(e,n,t){function r(){}function o(e,n,t){return function(){return i(e,[c.now()].concat(u(arguments)),n?null:this,t),n?void 0:this}}var i=e("handle"),a=e(2),u=e(3),f=e("ee").get("tracer"),c=e("loader"),s=NREUM;"undefined"==typeof window.newrelic&&(newrelic=s);var p=["setPageViewName","setCustomAttribute","setErrorHandler","finished","addToTrace","inlineHit","addRelease"],d="api-",l=d+"ixn-";a(p,function(e,n){s[n]=o(d+n,!0,"api")}),s.addPageAction=o(d+"addPageAction",!0),s.setCurrentRouteName=o(d+"routeName",!0),n.exports=newrelic,s.interaction=function(){return(new r).get()};var m=r.prototype={createTracer:function(e,n){var t={},r=this,o="function"==typeof n;return i(l+"tracer",[c.now(),e,t],r),function(){if(f.emit((o?"":"no-")+"fn-start",[c.now(),r,o],t),o)try{return n.apply(this,arguments)}finally{f.emit("fn-end",[c.now()],t)}}}};a("setName,setAttribute,save,ignore,onEnd,getContext,end,get".split(","),function(e,n){m[n]=o(l+n)}),newrelic.noticeError=function(e){"string"==typeof e&&(e=new Error(e)),i("err",[e,c.now()])}},{}],2:[function(e,n,t){function r(e,n){var t=[],r="",i=0;for(r in e)o.call(e,r)&&(t[i]=n(r,e[r]),i+=1);return t}var o=Object.prototype.hasOwnProperty;n.exports=r},{}],3:[function(e,n,t){function r(e,n,t){n||(n=0),"undefined"==typeof t&&(t=e?e.length:0);for(var r=-1,o=t-n||0,i=Array(o<0?0:o);++r<o;)i[r]=e[n+r];return i}n.exports=r},{}],4:[function(e,n,t){n.exports={exists:"undefined"!=typeof window.performance&&window.performance.timing&&"undefined"!=typeof window.performance.timing.navigationStart}},{}],ee:[function(e,n,t){function r(){}function o(e){function n(e){return e&&e instanceof r?e:e?f(e,u,i):i()}function t(t,r,o,i){if(!d.aborted||i){e&&e(t,r,o);for(var a=n(o),u=m(t),f=u.length,c=0;c<f;c++)u[c].apply(a,r);var p=s[y[t]];return p&&p.push([b,t,r,a]),a}}function l(e,n){v[e]=m(e).concat(n)}function m(e){return v[e]||[]}function w(e){return p[e]=p[e]||o(t)}function g(e,n){c(e,function(e,t){n=n||"feature",y[t]=n,n in s||(s[n]=[])})}var v={},y={},b={on:l,emit:t,get:w,listeners:m,context:n,buffer:g,abort:a,aborted:!1};return b}function i(){return new r}function a(){(s.api||s.feature)&&(d.aborted=!0,s=d.backlog={})}var u="nr@context",f=e("gos"),c=e(2),s={},p={},d=n.exports=o();d.backlog=s},{}],gos:[function(e,n,t){function r(e,n,t){if(o.call(e,n))return e[n];var r=t();if(Object.defineProperty&&Object.keys)try{return Object.defineProperty(e,n,{value:r,writable:!0,enumerable:!1}),r}catch(i){}return e[n]=r,r}var o=Object.prototype.hasOwnProperty;n.exports=r},{}],handle:[function(e,n,t){function r(e,n,t,r){o.buffer([e],r),o.emit(e,n,t)}var o=e("ee").get("handle");n.exports=r,r.ee=o},{}],id:[function(e,n,t){function r(e){var n=typeof e;return!e||"object"!==n&&"function"!==n?-1:e===window?0:a(e,i,function(){return o++})}var o=1,i="nr@id",a=e("gos");n.exports=r},{}],loader:[function(e,n,t){function r(){if(!x++){var e=h.info=NREUM.info,n=d.getElementsByTagName("script")[0];if(setTimeout(s.abort,3e4),!(e&&e.licenseKey&&e.applicationID&&n))return s.abort();c(y,function(n,t){e[n]||(e[n]=t)}),f("mark",["onload",a()+h.offset],null,"api");var t=d.createElement("script");t.src="https://"+e.agent,n.parentNode.insertBefore(t,n)}}function o(){"complete"===d.readyState&&i()}function i(){f("mark",["domContent",a()+h.offset],null,"api")}function a(){return E.exists&&performance.now?Math.round(performance.now()):(u=Math.max((new Date).getTime(),u))-h.offset}var u=(new Date).getTime(),f=e("handle"),c=e(2),s=e("ee"),p=window,d=p.document,l="addEventListener",m="attachEvent",w=p.XMLHttpRequest,g=w&&w.prototype;NREUM.o={ST:setTimeout,SI:p.setImmediate,CT:clearTimeout,XHR:w,REQ:p.Request,EV:p.Event,PR:p.Promise,MO:p.MutationObserver};var v=""+location,y={beacon:"bam.nr-data.net",errorBeacon:"bam.nr-data.net",agent:"js-agent.newrelic.com/nr-1044.min.js"},b=w&&g&&g[l]&&!/CriOS/.test(navigator.userAgent),h=n.exports={offset:u,now:a,origin:v,features:{},xhrWrappable:b};e(1),d[l]?(d[l]("DOMContentLoaded",i,!1),p[l]("load",r,!1)):(d[m]("onreadystatechange",o),p[m]("onload",r)),f("mark",["firstbyte",u],null,"api");var x=0,E=e(4)},{}]},{},["loader"]);</script>
<meta http-equiv="x-ua-compatible" content="ie=edge, chrome=1" />
<meta name="MobileOptimized" content="width" />
<meta name="HandheldFriendly" content="true" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<meta http-equiv="cleartype" content="on" />
  <link rel="apple-touch-icon" sizes="57x57" href="/profiles/dcco/themes/dcco2017/favicons/apple-icon-57x57.png">
  <link rel="apple-touch-icon" sizes="60x60" href="/profiles/dcco/themes/dcco2017/favicons/apple-icon-60x60.png">
  <link rel="apple-touch-icon" sizes="72x72" href="/profiles/dcco/themes/dcco2017/favicons/apple-icon-72x72.png">
  <link rel="apple-touch-icon" sizes="76x76" href="/profiles/dcco/themes/dcco2017/favicons/apple-icon-76x76.png">
  <link rel="apple-touch-icon" sizes="114x114" href="/profiles/dcco/themes/dcco2017/favicons/apple-icon-114x114.png">
  <link rel="apple-touch-icon" sizes="120x120" href="/profiles/dcco/themes/dcco2017/favicons/apple-icon-120x120.png">
  <link rel="apple-touch-icon" sizes="144x144" href="/profiles/dcco/themes/dcco2017/favicons/apple-icon-144x144.png">
  <link rel="apple-touch-icon" sizes="152x152" href="/profiles/dcco/themes/dcco2017/favicons/apple-icon-152x152.png">
  <link rel="apple-touch-icon" sizes="180x180" href="/profiles/dcco/themes/dcco2017/favicons/apple-icon-180x180.png">
  <link rel="icon" type="image/png" sizes="192x192"  href="/profiles/dcco/themes/dcco2017/favicons/android-icon-192x192.png">
  <link rel="icon" type="image/png" sizes="32x32" href="/profiles/dcco/themes/dcco2017/favicons/favicon-32x32.png">
  <link rel="icon" type="image/png" sizes="96x96" href="/profiles/dcco/themes/dcco2017/favicons/favicon-96x96.png">
  <link rel="icon" type="image/png" sizes="16x16" href="/profiles/dcco/themes/dcco2017/favicons/favicon-16x16.png">
  <link rel="manifest" href="/manifest.json">

  <meta name="twitter:card" content="summary">
  <meta name="twitter:site" content="@drupalcolorado">
  <meta name="twitter:creator" content="@drupalcolorado">

  <meta name="msapplication-TileColor" content="#ffffff">
  <meta name="msapplication-TileImage" content="/profiles/dcco/themes/dcco2017/favicons/ms-icon-144x144.png">

  <meta name="theme-color" content="#ffffff">
  <link type="text/css" rel="stylesheet" href="https://dev-2017drupalcampcoloradoorg.pantheonsite.io/sites/default/files/css/css_QKQZsniKY0IGMqgYDWKEqZwlpxg2aTEnsadFc49SE68.css" media="all" />
<link type="text/css" rel="stylesheet" href="https://dev-2017drupalcampcoloradoorg.pantheonsite.io/sites/default/files/css/css_sHwv7Trjx15HruMISXo6vhm3rC5Z_VAN-jD1BaWvyVw.css" media="all" />
<link type="text/css" rel="stylesheet" href="https://dev-2017drupalcampcoloradoorg.pantheonsite.io/sites/default/files/css/css_xQMZVFUH5e9HxEA_D38qOoMcdEpq4RXGoXdlYTfNdhw.css" media="all" />
<link type="text/css" rel="stylesheet" href="https://dev-2017drupalcampcoloradoorg.pantheonsite.io/sites/default/files/css/css_47DEQpj8HBSa-_TImW-5JCeuQeRkm5NMpJWZG3hSuFU.css" media="print" />
  <script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
<script type="text/javascript">
<!--//--><![CDATA[//><!--
window.jQuery || document.write("<script src='/profiles/dcco/modules/contrib/jquery_update/replace/jquery/1.8/jquery.min.js'>\x3C/script>")
//--><!]]>
</script>
<script type="text/javascript" src="https://dev-2017drupalcampcoloradoorg.pantheonsite.io/sites/default/files/js/js_V1ZuwJK9uzfm6fFffOcHHubfxnimoxnbgG58pvTQdpY.js"></script>
<script type="text/javascript" src="https://dev-2017drupalcampcoloradoorg.pantheonsite.io/sites/default/files/js/js_gPqjYq7fqdMzw8-29XWQIVoDSWTmZCGy9OqaHppNxuQ.js"></script>
<script type="text/javascript">
<!--//--><![CDATA[//><!--
(function(i,s,o,g,r,a,m){i["GoogleAnalyticsObject"]=r;i[r]=i[r]||function(){(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)})(window,document,"script","https://dev-2017drupalcampcoloradoorg.pantheonsite.io/sites/default/files/googleanalytics/analytics.js?ow6dx3","ga");ga("create", "UA-9027944-1", {"cookieDomain":"auto"});ga("send", "pageview");
//--><!]]>
</script>
<script type="text/javascript" src="https://dev-2017drupalcampcoloradoorg.pantheonsite.io/sites/default/files/js/js_4npi6EbEtnEHMNg3eIuwrCQ-8C0n5vT0Zvd7xItV3zg.js"></script>
<script type="text/javascript" src="https://dev-2017drupalcampcoloradoorg.pantheonsite.io/sites/default/files/js/js_3y76IweaI2QkHQVNTXU76MtcT1wPPfo7KoFDai0hHO4.js"></script>
<script type="text/javascript">
<!--//--><![CDATA[//><!--
jQuery.extend(Drupal.settings, {"basePath":"\/","pathPrefix":"","ajaxPageState":{"theme":"dcco2017","theme_token":"a_3Gv3IJmRXK7qORx2mfegam5kPGxFq221C7H8mNc58","js":{"\/\/ajax.googleapis.com\/ajax\/libs\/jquery\/1.8.3\/jquery.min.js":1,"0":1,"misc\/jquery.once.js":1,"misc\/drupal.js":1,"profiles\/dcco\/modules\/contrib\/google_analytics\/googleanalytics.js":1,"1":1,"profiles\/dcco\/themes\/dcco2017\/js\/responsive-nav\/responsive-nav.min.js":1,"profiles\/dcco\/themes\/dcco2017\/js\/menu.js":1,"profiles\/dcco\/themes\/dcco2017\/js\/main.js":1,"profiles\/dcco\/themes\/dcco2017\/js\/responsive-nav\/responsive-nav.js":1,"profiles\/dcco\/themes\/dcco2017\/js\/vendor\/slick\/slick.js":1,"profiles\/dcco\/themes\/dcco2017\/js\/stacktable\/stacktable.js":1},"css":{"modules\/system\/system.base.css":1,"modules\/system\/system.menus.css":1,"modules\/system\/system.messages.css":1,"modules\/system\/system.theme.css":1,"modules\/comment\/comment.css":1,"profiles\/dcco\/modules\/contrib\/date\/date_api\/date.css":1,"profiles\/dcco\/modules\/contrib\/date\/date_popup\/themes\/datepicker.1.7.css":1,"modules\/field\/theme\/field.css":1,"profiles\/dcco\/modules\/contrib\/mollom\/mollom.css":1,"modules\/node\/node.css":1,"modules\/search\/search.css":1,"modules\/user\/user.css":1,"sites\/all\/modules\/youtube\/css\/youtube.css":1,"profiles\/dcco\/modules\/contrib\/views\/css\/views.css":1,"profiles\/dcco\/modules\/contrib\/ckeditor\/css\/ckeditor.css":1,"profiles\/dcco\/modules\/contrib\/ctools\/css\/ctools.css":1,"profiles\/dcco\/themes\/dcco2017\/js\/responsive-nav\/responsive-nav.css":1,"profiles\/dcco\/themes\/center\/css\/override\/kill\/ctools.css":1,"profiles\/dcco\/themes\/center\/css\/override\/kill\/field.css":1,"profiles\/dcco\/themes\/center\/css\/override\/kill\/node.css":1,"profiles\/dcco\/themes\/center\/css\/override\/kill\/system.messages.css":1,"profiles\/dcco\/themes\/center\/css\/override\/kill\/system.menus.css":1,"profiles\/dcco\/themes\/center\/css\/override\/kill\/user.css":1,"profiles\/dcco\/themes\/center\/css\/override\/kill\/views.css":1,"profiles\/dcco\/themes\/center\/css\/override\/kill\/field_collection.theme.css":1,"profiles\/dcco\/themes\/center\/css\/override\/keep\/system.base.css":1,"profiles\/dcco\/themes\/center\/css\/override\/keep\/system.theme.css":1,"profiles\/dcco\/themes\/center\/css\/override\/keep\/search.css":1,"profiles\/dcco\/themes\/center\/css\/override\/keep\/vertical-tabs.css":1,"profiles\/dcco\/themes\/dcco2017\/js\/vendor\/slick\/slick.css":1,"profiles\/dcco\/themes\/dcco2017\/css\/screen.css":1,"profiles\/dcco\/themes\/dcco2017\/css\/override\/keep\/print.css":1}},"googleanalytics":{"trackOutbound":1,"trackMailto":1,"trackDownload":1,"trackDownloadExtensions":"7z|aac|arc|arj|asf|asx|avi|bin|csv|doc(x|m)?|dot(x|m)?|exe|flv|gif|gz|gzip|hqx|jar|jpe?g|js|mp(2|3|4|e?g)|mov(ie)?|msi|msp|pdf|phps|png|ppt(x|m)?|pot(x|m)?|pps(x|m)?|ppam|sld(x|m)?|thmx|qtm?|ra(m|r)?|sea|sit|tar|tgz|torrent|txt|wav|wma|wmv|wpd|xls(x|m|b)?|xlt(x|m)|xlam|xml|z|zip"}});
//--><!]]>
</script>
  <script type="text/javascript" src="//use.typekit.net/tpk4uum.js"></script>
  <script type="text/javascript">try{Typekit.load();}catch(e){}</script>
</head>

<body class="html not-front not-logged-in no-sidebars page-user-personal-information page-user-personal-information-mrc" >
  <div id="skip-link">
    <a href="#main-content" class="element-invisible element-focusable">Skip to main content</a>
  </div>
  <div id="page" class="page">

  <header id="header" class="clearfix">

    <a href="/" ><img src="/profiles/dcco/themes/dcco2017/img/druplicon.svg" alt="Druplicon Sun" /></a>
    
          <div id="utility">
            <div id="block-system-user-menu" class="block block-system block-menu">

      
  <div  class="block-content block-content">
    <ul class="nav"><li class="first leaf nav-item login"><a href="/user/login?current=user-personal-information/Mr.C" title="" class="nav-link link-login">Log In</a></li>
<li class="last leaf nav-item register"><a href="/register" title="" class="nav-link link-register">Register</a></li>
</ul>  </div>
</div>
      </div>
    
          <div id="navigation" class="clearfix">
            <div id="block-system-main-menu" class="block block-system block-menu">

      
  <div  class="block-content block-content">
    <ul class="nav nav-inline"><li class="first leaf nav-item sponsors"><a href="/sponsors" class="nav-link link-sponsors">Sponsors</a></li>
<li class="leaf nav-item community"><a href="/all-user-profiles" title="Community" class="nav-link link-community">Community</a></li>
<li class="leaf nav-item travel"><a href="/travel" title="Travel" class="nav-link link-travel">Travel</a></li>
<li class="leaf nav-item sessions"><a href="/content/camp-schedule" title="Session Schedule" class="nav-link link-sessions">Sessions</a></li>
<li class="leaf nav-item training"><a href="/training" title="Training sessions on Friday" class="nav-link link-training">Training</a></li>
<li class="last leaf nav-item summit"><a href="http://nvite.com/DCCO2017/" title="Nonprofit, Education and Government Summit" class="nav-link link-summit">Summit</a></li>
</ul>  </div>
</div>
      </div>
      </header>




  
  <div id="main">

      
    <? // We only support first sidebar at the moment. ?>
    
      <div id="main-content" class="">

                
        <div class="l--constrained">
          <div id="content">

            
            
            
                <div class="view view-user-personal-information view-id-user_personal_information view-display-id-page single-user view-dom-id-097359a9f128ff418efe6cda41c579ff">
            <div class="view-header">
      <h1 class="page-title">Say hello to user Mr.C</h1>
    </div>
  
  
  
      <div class="view-content">
      <div class="community_wrapper">    <ul class="community_users">          <li class="row">  
          <div class="float--right"><a href="/users/mrc#profile-personal_information"><img typeof="foaf:Image" src="https://dev-2017drupalcampcoloradoorg.pantheonsite.io/sites/default/files/styles/medium/public/default_images/default-avatar_0.png?itok=9XeI8IK6" alt="" /></a></div>    
  <span class="views-field views-field-field-last-name">        <strong class="field-content"><h3>Scott Cavness</h3></strong>  </span>  
          <div class="bio">Drupal tinkerer.</div>    
  <div class="cf">    <h4 class="label">Job Title: </h4>    <h4 class="field">Back End Developer</h4>  </div>  
          <div class="button--primary"></div>  </li>
      </ul></div>    </div>
  
  
  
  
  
  
</div>
          </div>
        </div>

        
              </div>

      
    </div>

  <div id="footer">
  <div class="clearfix">
        <div id="block-menu-menu-social-menu" class="block block-menu">

      
  <div  class="block-content block-content">
    <ul class="nav"><li class="first last leaf nav-item stayupdated"><a href="http://twitter.com/drupalcolorado" title="Drupal Colorado Twitter Account" class="nav-link link-stayupdated">Stay Updated</a></li>
</ul>  </div>
</div>
<div id="block-menu-menu-footer-menu" class="block block-menu">

      
  <div  class="block-content block-content">
    <ul class="nav"><li class="first leaf nav-item sponsors"><a href="/sponsors" title="Sponsors" class="nav-link link-sponsors">Sponsors</a></li>
<li class="leaf nav-item community"><a href="/all-user-profiles" title="Community" class="nav-link link-community">Community</a></li>
<li class="leaf nav-item travel"><a href="/travel" title="Travel" class="nav-link link-travel">Travel</a></li>
<li class="leaf nav-item register"><a href="/register" title="Register" class="nav-link link-register">Register</a></li>
<li class="leaf nav-item contact"><a href="/content/contact" title="Contact" class="nav-link link-contact">Contact</a></li>
<li class="leaf nav-item login"><a href="/user/login?current=user-personal-information/Mr.C" title="Log In" class="nav-link link-login">Log In</a></li>
<li class="last leaf nav-item training"><a href="/training" title="Training Sessions" class="nav-link link-training">Training</a></li>
</ul>  </div>
</div>
  </div>
</div>

  <div id="admin-footer">
        <div id="block-block-3" class="block block-block">

      
  <div  class="block-content block-content">
    <p>Powered by <a class="pantheon-anchor" href="https://pantheon.io/" target="_blank" title="Hosting provided by Pantheon">Pantheon</a></p>
  </div>
</div>
<div id="block-system-powered-by" class="block block-system">

      
  <div  class="block-content block-content">
    <span>Powered by <a href="https://www.drupal.org">Drupal</a></span>  </div>
</div>
  </div>

</div>
<script type="text/javascript">window.NREUM||(NREUM={});NREUM.info={"beacon":"bam.nr-data.net","licenseKey":"1bdd729938","applicationID":"31318101","transactionName":"Z1ADZhZRXEUDVRIKWF4aIFEQWV1YTUAPBkBDahFTA1U=","queueTime":0,"applicationTime":118,"atts":"SxcAEF5LT0s=","errorBeacon":"bam.nr-data.net","agent":""}</script></body>
</html>
